import{l as o,c as r}from"../chunks/fpF5R9S-.js";export{o as load_css,r as start};
