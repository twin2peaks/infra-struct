import{l as o,a as r}from"../chunks/S1t9JV3G.js";export{o as load_css,r as start};
