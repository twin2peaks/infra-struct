import{l as o,c as r}from"../chunks/Gn2X64tP.js";export{o as load_css,r as start};
