const t="https://twin2peaks.github.io/infra-struct/";export{t as B};
