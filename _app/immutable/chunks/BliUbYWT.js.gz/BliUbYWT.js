const t="ttps://twin2peaks.github.io/infra-struct";export{t as B};
